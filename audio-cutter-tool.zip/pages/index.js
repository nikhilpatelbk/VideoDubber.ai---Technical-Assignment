
import React, { useState, useRef, useEffect } from 'react';
import { Button, Slider, Container, Paper, Text, Title, Stack } from '@mantine/core';
import WaveSurfer from 'wavesurfer.js';

const HomePage = () => {
  const [audioFile, setAudioFile] = useState(null);
  const [waveformReady, setWaveformReady] = useState(false);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);
  const waveformRef = useRef(null);
  const wavesurfer = useRef(null);

  useEffect(() => {
    if (waveformRef.current && audioFile) {
      wavesurfer.current = WaveSurfer.create({
        container: waveformRef.current,
        waveColor: '#A8DBA8',
        progressColor: '#3B8686',
      });

      wavesurfer.current.on('ready', () => {
        setWaveformReady(true);
        setEndTime(wavesurfer.current.getDuration());
      });

      wavesurfer.current.load(URL.createObjectURL(audioFile));
    }

    return () => wavesurfer.current && wavesurfer.current.destroy();
  }, [audioFile]);

  const handleFileChange = (event) => {
    setAudioFile(event.target.files[0]);
    setWaveformReady(false);
  };

  const handlePlay = () => {
    if (wavesurfer.current) {
      wavesurfer.current.play();
    }
  };

  const handlePause = () => {
    if (wavesurfer.current) {
      wavesurfer.current.pause();
    }
  };

  const handleCut = () => {
    if (wavesurfer.current) {
      const audioContext = new AudioContext();
      const source = audioContext.createBufferSource();
    }
  };

  return (
    <Container>
      <Title align="center" mb="md">Serverless Audio Cutter Tool</Title>
      <Paper shadow="md" padding="lg">
        <Stack align="center">
          <Button onClick={() => document.getElementById('audio-upload').click()}>
            Upload Audio
          </Button>
          <input
            id="audio-upload"
            type="file"
            accept="audio/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
        </Stack>

        {audioFile && (
          <>
            <Paper mt="md" padding="md" shadow="xs">
              <div ref={waveformRef} id="waveform" style={{ width: '100%' }}></div>

              {waveformReady && (
                <div style={{ marginTop: '20px' }}>
                  <Text>Start Time: {startTime.toFixed(2)} seconds</Text>
                  <Slider
                    value={startTime}
                    onChange={setStartTime}
                    min={0}
                    max={wavesurfer.current.getDuration()}
                    step={0.01}
                  />
                  <Text>End Time: {endTime.toFixed(2)} seconds</Text>
                  <Slider
                    value={endTime}
                    onChange={setEndTime}
                    min={0}
                    max={wavesurfer.current.getDuration()}
                    step={0.01}
                  />
                </div>
              )}
            </Paper>

            <Stack mt="md" spacing="xs" align="center">
              <Button onClick={handlePlay}>Play</Button>
              <Button onClick={handlePause}>Pause</Button>
              <Button onClick={handleCut}>Cut Audio</Button>
            </Stack>
          </>
        )}
      </Paper>
    </Container>
  );
};

export default HomePage;
