
# Audio Cutter Tool

This project is a serverless audio cutter tool built using Next.js and Mantine UI. It replicates the functionality of [vocalremover.org/cutter](https://vocalremover.org/cutter) and uses JavaScript Web APIs to handle audio cutting and visualization without a backend.

## Features
- Audio selection and preview
- Cutting functionality with sliders for start and end times
- Waveform visualization using Web Audio API

## Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/audio-cutter-tool.git
   cd audio-cutter-tool
   ```

2. Install dependencies:
   ```bash
   yarn install
   ```

3. Run the development server:
   ```bash
   yarn dev
   ```

## Technologies Used
- Next.js
- Mantine UI
- Web Audio API
- wavesurfer.js (for waveform visualization)
